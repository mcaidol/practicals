#pip install nltk
import nltk
nltk.download('wordnet')
from nltk.stem import WordNetLemmatizer 
wordnet_lemmatizer = WordNetLemmatizer() 
text = input("Enter words for lemmatizing: ")
tokenization = nltk.word_tokenize(text)

for w in tokenization: 
    print("Lemma for {} is {}".format(w,wordnet_lemmatizer.lemmatize(w,'v'))) 
