#pip install nltk
import nltk
from collections import Counter
text="Guru99 is one of the best sites to learn WEB,SAP,Ethical Hacking and much more online. My name is Sadiq. And I'm working on a project"
lower_case=text.lower()
tokens=nltk.word_tokenize(lower_case)
tags=nltk.pos_tag(tokens)
print(tags)
counts=Counter(tag for word,tag in tags)

###for tag in tags:
### print(tag)
print(counts)
fd=nltk.FreqDist(tokens)
fd.plot()
fd1=nltk.FreqDist(counts)
fd1.plot()
