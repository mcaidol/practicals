#pip install nltk
import nltk
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
from nltk import pos_tag,word_tokenize,RegexpParser

sample_text="My little sister is playing with our pet cat and I am working"

tagged=pos_tag(word_tokenize(sample_text))
#Extract all parts of speech from any text
chunker =RegexpParser("""NP:{<DT>?<JJ>*<NN>}  
                         P:{<IN>}
                         V:{<V.*>}
                         PP:{<P> <NP>}
                         VP:{<V> <NP|PP>*}
                     """)
#print all parts of speech in above sentence.
output = chunker.parse(tagged)
print("After Extracting\n",output)
output.draw()
