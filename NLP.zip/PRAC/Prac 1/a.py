#pip install nltk
import nltk

s=open("sadiq.txt")
content=s.read()
sentences=nltk.sent_tokenize(content)

for sentence in sentences:
    print("\nSentence is:",sentence)
    print("\nTokens are:",nltk.word_tokenize(sentence))
    print() 
